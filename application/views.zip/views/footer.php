<footer class="footer" style="position:relative;">
               <div class="container-fluid">
                  
                  
               </div>
            </footer>
         </div>
      </div>
   </body>

   <script src="<?php echo js_url();?>jquery-3.2.1.min.js" type="text/javascript"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.4/moment.min.js"></script>
   <script src="<?php echo js_url();?>datetimepicker.js"></script>


   <script src="<?php echo js_url();?>bootstrap.min.js" type="text/javascript"></script>
    <script  src="<?php echo js_url();?>summernote/summernote.js"></script>

   <script src="<?php echo js_url();?>material.min.js" type="text/javascript"></script>
   <!--  Charts Plugin -->
   <script src="<?php echo js_url();?>chartist.min.js"></script>
   <!--  Dynamic Elements plugin -->
   <script src="<?php echo js_url();?>arrive.min.js"></script>
   <!--  PerfectScrollbar Library -->
   <script src="<?php echo js_url();?>perfect-scrollbar.jquery.min.js"></script>
   <!--  Notifications Plugin    -->
   <script src="<?php echo js_url();?>bootstrap-notify.js"></script>
   
  
   <script src="<?php echo js_url();?>material-dashboard.js?v=1.2.0"></script>
	 <script type="text/javascript" src="<?php echo js_url();?>maltiselect.js"></script>
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.jquery.min.js"></script>
   <script src="<?php echo js_url();?>demo.js"></script>

   <script src="<?php echo js_url();?>main.js"></script>
   <script src="<?php echo js_url();?>jssocials.min.js"></script>

          
      
        <script type="text/javascript" src="<?php echo js_url();?>plugin.js"></script>    


</html>